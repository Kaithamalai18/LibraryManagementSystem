package com.library.models;

public class Librarian {
    private int librarianId;
    private String name;
    private String password; // A simple password for authentication

    // Constructor to initialize a librarian
    public Librarian(int librarianId, String name, String password) {
        this.librarianId = librarianId;
        this.name = name;
        this.password = password;
    }

    // Getters and Setters
    public int getLibrarianId() {
        return librarianId;
    }

    public void setLibrarianId(int librarianId) {
        this.librarianId = librarianId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Authenticate librarian credentials
    public boolean authenticate(String inputPassword) {
        return this.password.equals(inputPassword);
    }

    @Override
    public String toString() {
        return "Librarian ID: " + librarianId + ", Name: " + name;
    }
}
