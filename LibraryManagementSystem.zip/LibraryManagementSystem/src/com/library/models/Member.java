package com.library.models;

import java.util.*;

public class Member {
    private int memberId;
    private String name;
    private List<Book> borrowedBooks;

    // Constructor to initialize a member
    public Member(int memberId, String name) {
        this.memberId = memberId;
        this.name = name;
        this.borrowedBooks = new ArrayList<>();
    }

    // Getters and Setters
    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Book> getBorrowedBooks() {
        return borrowedBooks;
    }

    // Borrow a book
    public void borrowBook(Book book) {
        borrowedBooks.add(book);
        book.setAvailable(false); // Mark the book as unavailable
    }

    // Return a book
    public void returnBook(Book book) {
        borrowedBooks.remove(book);
        book.setAvailable(true); // Mark the book as available
    }

    // Display member details
    @Override
    public String toString() {
        return "Member ID: " + memberId +
                ", Name: " + name +
                ", Borrowed Books: " + borrowedBooks.size();
    }

    // Static method to create a member via user input
    public static Member createMember() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Member ID: ");
        int memberId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter Member Name: ");
        String name = scanner.nextLine();

        return new Member(memberId, name);
    }
}
