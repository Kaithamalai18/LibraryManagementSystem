package com.library.management;

import com.library.models.Book;
import com.library.models.Librarian;
import com.library.models.Member;

import java.util.*;

public class Library {
    private List<Book> books; // List of books in the library
    private List<Member> members; // List of members in the library
    private Librarian librarian; // Default librarian for the system

    // Constructor to initialize the library and a default librarian
    public Library() {
        this.books = new ArrayList<>();
        this.members = new ArrayList<>();
        this.librarian = new Librarian(1, "Admin", "admin"); // Default credentials
    }

    // Add a new book to the library
    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added successfully: " + book);
    }

    // Add a new member to the library
    public void addMember(Member member) {
        members.add(member);
        System.out.println("Member added successfully: " + member);
    }

    // Issue a book to a member
    public void issueBook(int bookId, int memberId) {
        Book book = findBookById(bookId);
        Member member = findMemberById(memberId);

        if (book == null) {
            System.out.println("Book not found.");
            return;
        }

        if (member == null) {
            System.out.println("Member not found.");
            return;
        }

        if (!book.isAvailable()) {
            System.out.println("Book is already issued.");
            return;
        }

        book.setAvailable(false);
        System.out.println("Book issued to member: " + member.getName());
    }

    // Return a book from a member
    public void returnBook(int bookId, int memberId) {
        Book book = findBookById(bookId);
        Member member = findMemberById(memberId);

        if (book == null) {
            System.out.println("Book not found.");
            return;
        }

        if (member == null) {
            System.out.println("Member not found.");
            return;
        }

        if (book.isAvailable()) {
            System.out.println("Book is not issued to anyone.");
            return;
        }

        book.setAvailable(true);
        System.out.println("Book returned by member: " + member.getName());
    }

    // Search for books by title or author keyword
    public void searchBook(String keyword) {
        boolean found = false;
        for (Book book : books) {
            if (book.getTitle().toLowerCase().contains(keyword.toLowerCase()) ||
                    book.getAuthor().toLowerCase().contains(keyword.toLowerCase())) {
                System.out.println(book);
                found = true;
            }
        }

        if (!found) {
            System.out.println("No books found for the keyword: " + keyword);
        }
    }

    // Authenticate the librarian by password
    public boolean authenticateLibrarian(String password) {
        return librarian.authenticate(password);
    }

    // Find a book by its ID
    private Book findBookById(int bookId) {
        for (Book book : books) {
            if (book.getBookId() == bookId) {
                return book;
            }
        }
        return null;
    }

    // Find a member by their ID
    private Member findMemberById(int memberId) {
        for (Member member : members) {
            if (member.getMemberId() == memberId) {
                return member;
            }
        }
        return null;
    }
}
