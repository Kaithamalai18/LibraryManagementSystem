package com.library.main;

import com.library.management.Library;
import com.library.models.Book;
import com.library.models.Member;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Library library = new Library();

        while (true) {
            System.out.println("\n--- Library Management System ---\n");
            System.out.println("1. Add Book (Librarian Only)");
            System.out.println("2. Add Member (Librarian Only)");
            System.out.println("3. Issue Book");
            System.out.println("4. Return Book");
            System.out.println("5. Search Book");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");

            int choice = sc.nextInt();
            sc.nextLine(); // Consume newline

            switch (choice) {
                case 1: // Add Book
                    if (authenticateLibrarian(library, sc)) {
                        library.addBook(Book.createBook());
                    }
                    break;
                case 2: // Add Member
                    if (authenticateLibrarian(library, sc)) {
                        library.addMember(Member.createMember());
                    }
                    break;
                case 3: // Issue Book
                    System.out.print("Enter Book ID to issue: ");
                    int bookId = sc.nextInt();
                    System.out.print("Enter Member ID to issue to: ");
                    int memberId = sc.nextInt();
                    library.issueBook(bookId, memberId);
                    break;
                case 4: // Return Book
                    System.out.print("Enter Book ID to return: ");
                    bookId = sc.nextInt();
                    System.out.print("Enter Member ID returning the book: ");
                    memberId = sc.nextInt();
                    library.returnBook(bookId, memberId);
                    break;
                case 5: // Search Book
                    System.out.print("Enter keyword to search (title/author): ");
                    String keyword = sc.nextLine();
                    library.searchBook(keyword);
                    break;
                case 6: // Exit
                    System.out.println("Exiting system. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static boolean authenticateLibrarian(Library library, Scanner scanner) {
        System.out.print("Enter Librarian Password: ");
        String password = scanner.nextLine();
        if (library.authenticateLibrarian(password)) {
            System.out.println("Authentication successful!");
            return true;
        } else {
            System.out.println("Authentication failed! Access denied.");
            return false;
        }
    }
}
